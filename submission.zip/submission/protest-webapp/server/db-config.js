module.exports = {
  host: "cis550-proj.cl8t7peslmhx.us-east-1.rds.amazonaws.com",
  port: "3306",
  user: "guest",
  password: "pT2&gS3@By",
  database: "final_project"
};