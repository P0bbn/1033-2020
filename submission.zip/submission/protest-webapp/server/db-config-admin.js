// Private. Will not be included in submission
module.exports = {
  host: "cis550-proj.cl8t7peslmhx.us-east-1.rds.amazonaws.com",
  port: "3306",
  user: "admin",
  password: "edq8A!H:v0",
  database: "final_project"
};